import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-management-start',
  templateUrl: './management-start.component.html',
  styleUrls: ['./management-start.component.css']
})
export class ManagementStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
