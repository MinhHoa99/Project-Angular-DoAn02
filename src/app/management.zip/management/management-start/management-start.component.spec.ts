import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagementStartComponent } from './management-start.component';

describe('ManagementStartComponent', () => {
  let component: ManagementStartComponent;
  let fixture: ComponentFixture<ManagementStartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagementStartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagementStartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
