import { Component, OnInit, Input } from '@angular/core';
import { Items } from 'src/app/item/item.model';

@Component({
  selector: 'app-management-item',
  templateUrl: './management-item.component.html',
  styleUrls: ['./management-item.component.css']
})
export class ManagementItemComponent implements OnInit {
  @Input() items1: Items;
  @Input() index: number;
  constructor() { }

  ngOnInit() {
  }

}
