import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { from } from 'rxjs';
import { Items } from 'src/app/item/item.model';
import { ItemService } from 'src/app/item/item.service';


@Component({
  selector: 'app-management-list',
  templateUrl: './management-list.component.html',
  styleUrls: ['./management-list.component.css']
})
export class ManagementListComponent implements OnInit {
  items: Items[];

  constructor(private itemServ: ItemService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.itemServ.onChangeItem.subscribe(
      (items: Items[]) => this.items = items
    );
    this.items = this.itemServ.onGetItems();
  }

  onNewManagement() {
    this.router.navigate(['new'], {relativeTo: this.route});
  }


}
